import conanPoster from "@/assets/conan.jpg";
import onePiecePoster from "@/assets/onepiece.jpg";
import narutoPoster from "@/assets/naruto.jpg";
import aotPoster from "@/assets/aot.jpg";
import jjkPoster from "@/assets/jjk.jpg";
import demonSlayerPoster from "@/assets/demonslayer.jpg";

import dbsPoster from "@/assets/dbs.jpg";
import soloPoster from "@/assets/sololeveling.jpg";
import drStonePoster from "@/assets/drstone.jpg";
import kaijuPoster from "@/assets/kaiju8.jpg";
import mhaPoster from "@/assets/mha.jpg";
import hxhPoster from "@/assets/hxh.jpg";
import deathNotePoster from "@/assets/deathnote.jpg";
import opmPoster from "@/assets/opm.jpg";
import spyPoster from "@/assets/spyfamily.jpg";
import frierenPoster from "@/assets/frieren.jpg";

export type Episode = {
  number: number;
  title: string;
  duration: string;
  src: string;
};

export type Movie = {
  number: number;
  title: string;
  src: string;
};

export type Anime = {
  slug: string;
  titleAr: string;
  titleEn: string;
  year: number;
  studio: string;
  status: string;
  rating: number;
  genres: string[];
  shortStory: string;
  story: string;
  poster: string;
  /** Base streaming URL: episodes = baseUrl/ep/N, movies = baseUrl/movie/N. */
  baseUrl: string;
  episodeCount: number;
  episodeDuration: string;
  /** Optional hand-written titles for the first episodes. */
  episodeTitles?: string[];
  movieCount: number;
  movieTitles?: Record<number, string>;
};

/** Episodes are generated with a loop to keep the bundle tiny. */
export function getEpisodes(anime: Anime): Episode[] {
  const list: Episode[] = [];
  for (let i = 1; i <= anime.episodeCount; i++) {
    list.push({
      number: i,
      title: anime.episodeTitles?.[i - 1] ?? `الحلقة ${i}`,
      duration: anime.episodeDuration,
      src: buildStreamUrl(anime.baseUrl, "ep", i),
    });
  }
  return list;
}

/** Joins baseUrl + "/ep/N" or "/movie/N" (tolerates a trailing slash). */
export function buildStreamUrl(baseUrl: string, kind: "ep" | "movie", n: number) {
  return `${baseUrl.replace(/\/+$/, "")}/${kind}/${n}`;
}

/** Movies are generated with a loop as well. */
export function getMovies(anime: Anime): Movie[] {
  const list: Movie[] = [];
  for (let i = 1; i <= anime.movieCount; i++) {
    const name = anime.movieTitles?.[i];
    list.push({
      number: i,
      title: name ? `الفيلم ${i}: ${name}` : `الفيلم ${i}`,
      src: buildStreamUrl(anime.baseUrl, "movie", i),
    });
  }
  return list;
}

export const animeList: Anime[] = [
  {
    slug: "detective-conan",
    titleAr: "المحقق كونان",
    titleEn: "Detective Conan",
    year: 1996,
    studio: "TMS Entertainment",
    status: "مستمر",
    rating: 4.8,
    genres: ["غموض", "تحقيق", "إثارة"],
    shortStory:
      "طالب ثانوي عبقري في التحقيق يتحول إلى طفل، فيواصل كشف الجرائم بانتظار عودته إلى هيئته الأصلية.",
    story:
      "شينيتشي كودو طالبٌ في المرحلة الثانوية ذاع صيته بوصفه محققاً بارعاً لا يفوته أثر ولا تخدعه حيلة. وبينما كان يتعقّب صفقةً مشبوهة لمنظمة إجرامية غامضة، باغته أفرادها وأجبروه على تجرّع عقارٍ تجريبي كان من المفترض أن يقضي عليه، غير أنّ العقار أحدث أثراً لم يكن في الحسبان، إذ أعاد جسده إلى هيئة طفلٍ صغير مع بقاء عقله على حدّته وذكائه. اتخذ لنفسه اسم «كونان إيدوغاوا» وأقام في بيت صديقته ران موري ووالدها المحقق كوغورو، ومن هناك راح يحلّ أعقد القضايا من وراء ستار، يجمع الأدلة ويربط الخيوط حتى تنجلي الحقيقة، وهو لا يكفّ عن البحث عن المنظمة التي سلبته حياته الأولى.",
    poster: conanPoster,
    episodeTitles: ["المحقق الشهير يتحول إلى طفل", "قضية الرهينة في الحافلة", "لغز الغرفة المغلقة", "جريمة على متن القطار الأخير", "سرّ الرسالة المشفّرة", "مواجهة الرجل ذي الثوب الأسود"],
    baseUrl: "https://ok.ru",
    episodeCount: 1214,
    episodeDuration: "24 دقيقة",
    movieCount: 29,
    movieTitles: { 1: "القنبلة الموقوتة في ناطحة السحاب", 28: "العين الواحدة للمحقق الغامض", 29: "الفيلم الأحدث — 2026" },
  },
  {
    slug: "one-piece",
    titleAr: "ون بيس",
    titleEn: "One Piece",
    year: 1999,
    studio: "Toei Animation",
    status: "مستمر",
    rating: 4.9,
    genres: ["مغامرة", "أكشن", "خيال"],
    shortStory:
      "فتىً حالم يجمع طاقماً من القراصنة ويخوض البحار بحثاً عن الكنز الأعظم ولقب ملك القراصنة.",
    story:
      "في عالمٍ تتناثر فيه الجزر على امتداد بحارٍ لا تُحصى، انطلق مونكي دي لوفي، الفتى الذي أكسبته ثمرة الشيطان جسداً مطاطياً، في رحلةٍ لا تعرف التراجع بحثاً عن الكنز الأسطوري «ون بيس». يجمع حوله رفاقاً من أصحاب الأحلام الكبيرة: سيّاف يسعى لأن يكون الأقوى، وملاحةً تحلم برسم خريطة العالم، وطبّاخاً يبحث عن بحرٍ لم يره أحد. معاً يواجهون الأساطيل والقراصنة والحكومة العالمية، ويثبتون أنّ الحرية أغلى من كلّ ذهب البحر.",
    poster: onePiecePoster,
    episodeTitles: ["أنا لوفي! الفتى الذي سيصير ملك القراصنة", "ظهور السيّاف زورو", "اللصّة الماكرة نامي", "قرية الشراع والقنّاص أوسوب", "مطعم البحر والطبّاخ سانجي", "معركة قرية كوكو ياشي"],
    baseUrl: "https://ok.ru",
    episodeCount: 1169,
    episodeDuration: "24 دقيقة",
    movieCount: 15,
    movieTitles: { 13: "ون بيس: غولد", 14: "ون بيس: ستامبيد", 15: "ون بيس فيلم: ريد" },
  },
  {
    slug: "naruto",
    titleAr: "ناروتو",
    titleEn: "Naruto",
    year: 2002,
    studio: "Studio Pierrot",
    status: "مكتمل",
    rating: 4.7,
    genres: ["أكشن", "مغامرة", "قوى خارقة"],
    shortStory:
      "نينجا يتيم يحمل في داخله وحشاً مختوماً، يسعى بعزيمةٍ لا تلين ليصبح زعيم قريته.",
    story:
      "وُلد ناروتو أوزوماكي في قرية الورق المخفية ليلة هجوم الثعلب ذي الذيول التسعة، فخُتم الوحش في جسده الصغير ونشأ وحيداً ينظر إليه أهل القرية بعين الريبة. لكنّه لم يستسلم لليأس يوماً؛ اتخذ من المرح درعاً ومن العزيمة سلاحاً، وأعلن أمام الجميع أنّه سيصير هوكاجي القرية يوماً ما. ومع فريقه السابع يخوض الاختبارات والمعارك، ويتعلّم أنّ القوة الحقيقية تولد من الروابط التي تجمع الإنسان بمن يحب.",
    poster: narutoPoster,
    episodeTitles: ["ناروتو أوزوماكي يدخل الميدان", "الفريق السابع وكاكاشي هاتاكي", "اختبار الجرسين", "مهمة أرض الموج", "مواجهة على الجسر الكبير", "بداية اختبارات التشونين"],
    baseUrl: "https://ok.ru",
    episodeCount: 500,
    episodeDuration: "23 دقيقة",
    movieCount: 11,
    movieTitles: { 11: "بوروتو: ناروتو الفيلم" },
  },
  {
    slug: "attack-on-titan",
    titleAr: "هجوم العمالقة",
    titleEn: "Attack on Titan",
    year: 2013,
    studio: "Wit Studio / MAPPA",
    status: "مكتمل",
    rating: 4.9,
    genres: ["أكشن", "دراما", "تشويق"],
    shortStory:
      "بشرٌ يحتمون خلف أسوارٍ عملاقة من كائنات مرعبة، حتى يسقط السور وتبدأ الحقيقة بالانكشاف.",
    story:
      "منذ أكثر من قرن، انزوت البشرية خلف ثلاثة أسوارٍ شاهقة تحميها من عمالقةٍ لا تعرف الرحمة. عاش الناس في سلامٍ هشّ حتى ظهر عملاقٌ يفوق السور علوّاً فحطّم البوابة، وانهار معها كل شعورٍ بالأمان. فقد إيرين ييغر أمّه في ذلك اليوم، فأقسم مع رفيقيه ميكاسا وأرمين أن ينضمّ إلى فيلق الاستطلاع وأن يمحو العمالقة عن وجه الأرض. غير أنّ كل خطوةٍ خارج السور تكشف سرّاً أعمق، حتى يكتشف الجميع أنّ العدوّ الحقيقي ليس دائماً وراء الأسوار.",
    poster: aotPoster,
    episodeTitles: ["إليك يا مدينتي بعد ألفي عام", "ذلك اليوم: سقوط شيغانشينا", "ليلة حفل التخرّج", "أوّل معركة في تروست", "القوس والسهم والعملاق المدرّع", "استعادة البوابة"],
    baseUrl: "https://ok.ru",
    episodeCount: 88,
    episodeDuration: "24 دقيقة",
    movieCount: 4,
    movieTitles: { 1: "القوس والسهم القرمزي", 2: "أجنحة الحرية", 3: "صرخة الاستيقاظ", 4: "الهجوم الأخير" },
  },
  {
    slug: "jujutsu-kaisen",
    titleAr: "جوجوتسو كايسن",
    titleEn: "Jujutsu Kaisen",
    year: 2020,
    studio: "MAPPA",
    status: "مستمر",
    rating: 4.8,
    genres: ["أكشن", "خارق للطبيعة", "غموض"],
    shortStory:
      "طالبٌ يبتلع تعويذة ملعونة فيصير وعاءً لأقوى لعنة، وينضمّ إلى مدرسة سحرة الجوجوتسو.",
    story:
      "يوجي إيتادوري فتىً عادي يتمتّع بقوّةٍ بدنية غير عادية، انقلبت حياته حين ابتلع إصبعاً ملعوناً يعود لسوكونا، ملك اللعنات، لينجو أصدقاؤه من الموت. ومنذ تلك اللحظة صار جسده سجناً لأخطر كائنٍ ملعون عرفه العالم. التحق بمعهد طوكيو لسحرة الجوجوتسو تحت رعاية المعلّم ساتورو غوجو، وبدأ رحلةً بين عالمين: عالمٌ يعيشه الناس في طمأنينة، وآخر تتغذّى فيه اللعنات على مشاعرهم السلبية في الظلّ.",
    poster: jjkPoster,
    episodeTitles: ["ريوميناكي سوكونا", "من أجل نفسي", "فتاة من حديد", "ولادة اللعنة المزدوجة", "معركة سجن المدرسة", "بعد المطر يأتي الصفاء"],
    baseUrl: "https://ok.ru",
    episodeCount: 47,
    episodeDuration: "24 دقيقة",
    movieCount: 1,
    movieTitles: { 1: "جوجوتسو كايسن 0" },
  },
  {
    slug: "demon-slayer",
    titleAr: "قاتل الشياطين",
    titleEn: "Demon Slayer: Kimetsu no Yaiba",
    year: 2019,
    studio: "ufotable",
    status: "مستمر",
    rating: 4.9,
    genres: ["أكشن", "مغامرة", "تاريخي"],
    shortStory:
      "فتىً يفقد عائلته على يد شيطان، فيمتشق سيفه ليعيد أخته الوحيدة إلى بشريّتها.",
    story:
      "في يابان عصر تايشو، كان تانجيرو كامادو فتىً طيّباً يعيل أسرته ببيع الفحم في قريةٍ جبلية هادئة. عاد ذات مساءٍ ليجد عائلته مذبوحة على يد شيطان، ولم تنجُ سوى أخته نيزوكو التي تحوّلت هي الأخرى إلى شيطانة، غير أنّ شيئاً من إنسانيّتها بقي حيّاً. حمل تانجيرو أخته على ظهره وانضمّ إلى فيلق قتلة الشياطين، يتدرّب على أنفاس الماء ويشحذ سيفه، ساعياً بلا كلل إلى الشيطان الأول موزان كيبوتسوجي علّه يجد الدواء الذي يعيد لأخته صورتها الأولى.",
    poster: demonSlayerPoster,
    episodeTitles: ["القسوة", "المدرّب ساكونجي أوروكوداكي", "سايوري وماكومو", "الاختبار النهائي للاختيار", "سيفي الفولاذي", "شيطان المستنقع"],
    baseUrl: "https://ok.ru",
    episodeCount: 63,
    episodeDuration: "24 دقيقة",
    movieCount: 4,
    movieTitles: { 1: "قطار اللانهاية", 2: "قلعة اللانهاية — الجزء الأول", 3: "قلعة اللانهاية — الجزء الثاني", 4: "قلعة اللانهاية — الجزء الثالث" },
  },
  {
    slug: "dragon-ball-super", titleAr: "دراغون بول سوبر", titleEn: "Dragon Ball Super", year: 2015, studio: "Toei Animation", status: "مكتمل", rating: 4.6,
    genres: ["أكشن", "مغامرة", "خيال"],
    shortStory: "بعد هزيمة بو، يواجه غوكو وأصدقاؤه آلهة الدمار ومحاربي الأكوان الأخرى.",
    story: "يعود السلام إلى الأرض بعد القضاء على الشرير بو، لكنّ الهدوء لا يدوم طويلاً؛ إذ يستيقظ بيروس إله الدمار باحثاً عن «سوبر سايان الإله». يخوض غوكو وفيجيتا تدريبات تتجاوز حدود البشر، ويشاركان في بطولة القوة التي يتقرّر فيها مصير أكوانٍ بأكملها.",
    poster: dbsPoster, baseUrl: "https://ok.ru", episodeCount: 131, episodeDuration: "24 دقيقة", movieCount: 21,
    movieTitles: { 20: "دراغون بول سوبر: برولي", 21: "دراغون بول سوبر: سوبر هيرو" },
  },
  {
    slug: "solo-leveling", titleAr: "سولو ليفيلينغ", titleEn: "Solo Leveling", year: 2024, studio: "A-1 Pictures", status: "مستمر", rating: 4.7,
    genres: ["أكشن", "خيال", "مغامرة"],
    shortStory: "أضعف صيّاد في العالم يحصل على نظامٍ غامض يسمح له بالارتقاء بلا حدود.",
    story: "حين انفتحت البوابات التي تربط عالمنا بزنازين الوحوش، ظهر الصيّادون أصحاب القدرات. وكان سونغ جين وو أضعفهم جميعاً، حتى نجا من زنزانةٍ مزدوجة قاتلة ليجد نفسه «اللاعب» الوحيد لنظامٍ يمنحه المهام والمستويات، فيبدأ صعوده من القاع إلى القمّة.",
    poster: soloPoster, baseUrl: "https://ok.ru", episodeCount: 25, episodeDuration: "24 دقيقة", movieCount: 1,
    movieTitles: { 1: "سولو ليفيلينغ: الصحوة من جديد" },
  },
  {
    slug: "dr-stone", titleAr: "دكتور ستون", titleEn: "Dr. STONE", year: 2019, studio: "TMS Entertainment", status: "مستمر", rating: 4.6,
    genres: ["مغامرة", "خيال علمي", "كوميديا"],
    shortStory: "عبقري علوم يستيقظ بعد آلاف السنين من تحجّر البشرية ليعيد بناء الحضارة من الصفر.",
    story: "في لحظةٍ غامضة تحوّل البشر جميعاً إلى تماثيل حجرية. وبعد نحو ثلاثة آلاف وسبعمئة عام يستيقظ سينكو إيشيغامي، الفتى المولع بالعلم، ليقرّر إعادة الحضارة خطوةً خطوة بالكيمياء والفيزياء، من الصابون إلى المصابيح وحتى السفن.",
    poster: drStonePoster, baseUrl: "https://ok.ru", episodeCount: 81, episodeDuration: "24 دقيقة", movieCount: 1,
    movieTitles: { 1: "دكتور ستون: ريوسوي (حلقة خاصة)" },
  },
  {
    slug: "kaiju-no-8", titleAr: "كايجو رقم 8", titleEn: "Kaiju No. 8", year: 2024, studio: "Production I.G", status: "مستمر", rating: 4.5,
    genres: ["أكشن", "خيال علمي"],
    shortStory: "عامل تنظيف جثث الوحوش يتحوّل إلى وحشٍ خارق، فيسعى للانضمام إلى قوات الدفاع.",
    story: "يعمل كافكا هيبينو في تنظيف مخلّفات الوحوش العملاقة بعد المعارك، رغم حلمه القديم بالانضمام إلى قوات الدفاع. وحين يبتلع مخلوقاً صغيراً يتحوّل إلى كايجو ذي قوة هائلة، فيخفي سرّه ويخوض الاختبار ليقاتل إلى جانب البشر.",
    poster: kaijuPoster, baseUrl: "https://ok.ru", episodeCount: 23, episodeDuration: "24 دقيقة", movieCount: 0,
  },
  {
    slug: "my-hero-academia", titleAr: "بوكو نو هيرو أكاديميا", titleEn: "My Hero Academia", year: 2016, studio: "Bones", status: "مكتمل", rating: 4.6,
    genres: ["أكشن", "مدرسي", "أبطال خارقون"],
    shortStory: "فتى بلا قدرات في عالمٍ يملك فيه الجميع قوى خارقة يرث قوة أعظم الأبطال.",
    story: "في مجتمعٍ يولد فيه معظم الناس بقدرات خاصة، يحلم إيزوكو ميدوريا بأن يصبح بطلاً رغم أنه وُلد بلا قدرة. تتغيّر حياته حين يلتقي البطل الأسطوري أول مايت الذي يورّثه قوته «ون فور أول»، فيلتحق بأكاديمية يو إيه لتكوين الأبطال.",
    poster: mhaPoster, baseUrl: "https://ok.ru", episodeCount: 170, episodeDuration: "24 دقيقة", movieCount: 4,
    movieTitles: { 1: "البطلان", 2: "صعود الأبطال", 3: "مهمة الأبطال العالمية", 4: "أنت التالي" },
  },
  {
    slug: "hunter-x-hunter", titleAr: "صياد ضد صياد", titleEn: "Hunter x Hunter (2011)", year: 2011, studio: "Madhouse", status: "مكتمل", rating: 4.9,
    genres: ["مغامرة", "أكشن", "خيال"],
    shortStory: "فتىً يخوض اختبار الصيّادين الخطير بحثاً عن والده الذي تركه صغيراً.",
    story: "يكتشف غون فريكس أنّ والده الغائب صيّادٌ أسطوري، فيغادر جزيرته ليخوض اختبار الصيّادين العسير. هناك يصادق كيلوا وكورابيكا وليوريو، وينطلقون في مغامراتٍ تكشف لهم عالم «النين» ومنظمات إجرامية ومخلوقات تهدّد البشرية.",
    poster: hxhPoster, baseUrl: "https://ok.ru", episodeCount: 148, episodeDuration: "23 دقيقة", movieCount: 2,
    movieTitles: { 1: "العين القرمزية", 2: "المهمة الأخيرة" },
  },
  {
    slug: "death-note", titleAr: "مذكرة الموت", titleEn: "Death Note", year: 2006, studio: "Madhouse", status: "مكتمل", rating: 4.8,
    genres: ["غموض", "إثارة", "نفسي"],
    shortStory: "طالب عبقري يعثر على دفترٍ خارق، فيدخل في مواجهة ذكاء مع أعظم محقق في العالم.",
    story: "يعثر لايت ياغامي على دفترٍ أسود أسقطه إله الموت ريوك، ويكتشف أنّ له قدرة خارقة. يقرّر لايت استخدامه لتطهير العالم من المجرمين، فيظهر المحقق الغامض «إل» ليبدأ صراع عقولٍ لا يعرف فيه أيّهما الصيّاد وأيّهما الفريسة.",
    poster: deathNotePoster, baseUrl: "https://ok.ru", episodeCount: 37, episodeDuration: "23 دقيقة", movieCount: 0,
  },
  {
    slug: "one-punch-man", titleAr: "ون بنش مان", titleEn: "One Punch Man", year: 2015, studio: "Madhouse / J.C.Staff", status: "مستمر", rating: 4.7,
    genres: ["أكشن", "كوميديا", "أبطال خارقون"],
    shortStory: "بطلٌ يهزم أيّ خصمٍ بلكمة واحدة، ويبحث عن تحدٍّ حقيقي يعيد إليه الحماسة.",
    story: "بعد ثلاث سنوات من التدريب الصارم، أصبح سايتاما قوياً إلى حدّ يهزم فيه أيّ وحشٍ بلكمة واحدة. لكنّ هذه القوة سلبته متعة القتال، فينضمّ إلى رابطة الأبطال مع تلميذه جينوس باحثاً عن خصمٍ يستحقّ المواجهة.",
    poster: opmPoster, baseUrl: "https://ok.ru", episodeCount: 36, episodeDuration: "24 دقيقة", movieCount: 0,
  },
  {
    slug: "spy-x-family", titleAr: "سباي إكس فاميلي", titleEn: "Spy x Family", year: 2022, studio: "Wit Studio / CloverWorks", status: "مستمر", rating: 4.7,
    genres: ["كوميديا", "أكشن", "عائلي"],
    shortStory: "جاسوس وقاتلة مأجورة وطفلة تقرأ الأفكار يشكّلون عائلة مزيّفة من أجل مهمة سرّية.",
    story: "يُكلَّف الجاسوس «توايلايت» بتكوين عائلة للاقتراب من هدفٍ سياسي خطير، فيتبنّى الطفلة آنيا ويتزوّج يور. لا يعلم أنّ زوجته قاتلة محترفة، ولا أنّ ابنته تقرأ الأفكار، فتتوالى المواقف الطريفة والمغامرات المثيرة.",
    poster: spyPoster, baseUrl: "https://ok.ru", episodeCount: 50, episodeDuration: "24 دقيقة", movieCount: 1,
    movieTitles: { 1: "سباي إكس فاميلي: كود وايت" },
  },
  {
    slug: "frieren", titleAr: "فريرن: بعد نهاية الرحلة", titleEn: "Frieren: Beyond Journey's End", year: 2023, studio: "Madhouse", status: "مستمر", rating: 4.9,
    genres: ["خيال", "مغامرة", "دراما"],
    shortStory: "ساحرة من الجان تعيش آلاف السنين تبدأ رحلة جديدة لفهم البشر بعد رحيل رفاقها.",
    story: "بعد أن هزمت فريرن ورفاقها ملك الشياطين، افترقوا لتعود هي إلى حياتها الطويلة. وحين يرحل رفيقها البطل هيميل بعد خمسين عاماً، تدرك أنها لم تعرفه حقاً، فتنطلق في رحلةٍ جديدة لتفهم معنى الذكريات والمشاعر الإنسانية.",
    poster: frierenPoster, baseUrl: "https://ok.ru", episodeCount: 38, episodeDuration: "24 دقيقة", movieCount: 0,
  },
];

export const getAnimeBySlug = (slug: string) =>
  animeList.find((anime) => anime.slug === slug);

export const featuredAnime = animeList[0] as Anime;
