import { Link } from "@tanstack/react-router";
import { Play, Star } from "lucide-react";
import type { Anime } from "@/data/anime";

export function AnimeCard({ anime }: { anime: Anime }) {
  return (
    <Link
      to="/anime/$slug"
      params={{ slug: anime.slug }}
      className="card-hover group block overflow-hidden rounded-2xl border border-border/70 bg-card"
    >
      <div className="relative aspect-[3/4] overflow-hidden">
        <img
          src={anime.poster}
          alt={`بوستر أنمي ${anime.titleAr} - ${anime.titleEn}`}
          loading="lazy"
          width={768}
          height={1024}
          className="size-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/25 to-transparent" />
        <span className="absolute left-3 top-3 flex items-center gap-1 rounded-full bg-background/80 px-2 py-1 text-xs font-bold text-gold">
          <Star className="size-3 fill-gold text-gold" />
          {anime.rating.toFixed(1)}
        </span>
        <span className="neon-ring absolute bottom-3 right-3 flex size-10 translate-y-2 items-center justify-center rounded-full bg-primary opacity-0 transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100">
          <Play className="size-4 fill-primary-foreground text-primary-foreground" />
        </span>
      </div>

      <div className="space-y-2 p-4">
        <h3 className="text-base font-bold leading-tight">{anime.titleAr}</h3>
        <p className="text-xs text-muted-foreground" dir="ltr">
          {anime.titleEn}
        </p>
        <ul className="flex flex-wrap gap-1.5 pt-1">
          {anime.genres.map((genre) => (
            <li
              key={genre}
              className="rounded-full border border-primary/25 bg-primary/10 px-2 py-0.5 text-[11px] text-primary"
            >
              {genre}
            </li>
          ))}
        </ul>
      </div>
    </Link>
  );
}
