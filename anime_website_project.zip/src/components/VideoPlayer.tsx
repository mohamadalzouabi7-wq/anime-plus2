import { useEffect, useState } from "react";
import { AlertTriangle, Loader2, RotateCw } from "lucide-react";
import { Button } from "@/components/ui/button";

type Status = "loading" | "ready" | "error";

const LOAD_TIMEOUT_MS = 15000;

function isValidUrl(src: string) {
  try {
    const u = new URL(src);
    return u.protocol === "https:" || u.protocol === "http:";
  } catch {
    return false;
  }
}

export function VideoPlayer({ src, title }: { src: string; title: string }) {
  const [status, setStatus] = useState<Status>("loading");
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    if (!isValidUrl(src)) {
      setStatus("error");
      return;
    }
    setStatus("loading");
    const timer = window.setTimeout(() => {
      setStatus((s) => (s === "loading" ? "error" : s));
    }, LOAD_TIMEOUT_MS);
    return () => window.clearTimeout(timer);
  }, [src, attempt]);

  return (
    <div className="neon-ring relative overflow-hidden rounded-2xl bg-background">
      <div className="relative aspect-video w-full">
        {status !== "error" && isValidUrl(src) && (
          <iframe
            key={`${src}-${attempt}`}
            src={src}
            title={title}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
            allowFullScreen
            referrerPolicy="no-referrer"
            onLoad={() => setStatus("ready")}
            onError={() => setStatus("error")}
            className="absolute inset-0 size-full border-0"
          />
        )}

        {status === "loading" && (
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-background/60">
            <Loader2 className="size-10 animate-spin text-primary" />
          </div>
        )}

        {status === "error" && (
          <div
            role="alert"
            className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-card p-6 text-center"
          >
            <AlertTriangle className="size-10 text-primary sm:size-12" />
            <p className="max-w-md text-sm font-bold leading-7 sm:text-lg">
              عذراً، هناك ضغط مؤقت على سيرفر المشاهدة، يرجى تحديث الصفحة
            </p>
            <Button onClick={() => setAttempt((a) => a + 1)} className="rounded-full">
              <RotateCw className="size-4" />
              إعادة المحاولة
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
