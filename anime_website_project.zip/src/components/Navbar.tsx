import { useMemo, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { LogIn, Play, Search, UserRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { LoginModal } from "@/components/LoginModal";
import { animeList } from "@/data/anime";

export function Navbar() {
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [loginOpen, setLoginOpen] = useState(false);
  const [user, setUser] = useState<string | null>(null);

  const results = useMemo(() => {
    const term = query.trim().toLowerCase();
    if (!term) return [];
    return animeList
      .filter(
        (anime) =>
          anime.titleAr.includes(term) ||
          anime.titleEn.toLowerCase().includes(term) ||
          anime.genres.some((genre) => genre.includes(term)),
      )
      .slice(0, 5);
  }, [query]);

  return (
    <header className="sticky top-0 z-50 border-b border-border/60 bg-background/85 backdrop-blur-xl">
      <nav className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4 sm:gap-5">
        <Link to="/" className="flex shrink-0 items-center gap-2">
          <span className="neon-ring flex size-9 items-center justify-center rounded-xl bg-primary/15">
            <Play className="size-4 fill-primary text-primary" />
          </span>
          <span className="hidden text-lg font-extrabold sm:block">
            أنمي <span className="neon-text">بلس</span>
          </span>
        </Link>

        <div className="relative flex-1">
          <Search className="pointer-events-none absolute right-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(event) => {
              setQuery(event.target.value);
              setOpen(true);
            }}
            onFocus={() => setOpen(true)}
            onBlur={() => window.setTimeout(() => setOpen(false), 150)}
            placeholder="ابحث عن أنمي… مثل: ون بيس، ناروتو، غموض"
            aria-label="البحث عن أنمي"
            className="h-10 rounded-full border-border/70 bg-secondary/60 pr-10 text-sm"
          />

          {open && results.length > 0 && (
            <ul className="surface-panel absolute inset-x-0 top-12 overflow-hidden rounded-xl p-1 shadow-xl">
              {results.map((anime) => (
                <li key={anime.slug}>
                  <button
                    type="button"
                    className="flex w-full items-center gap-3 rounded-lg p-2 text-right transition-colors hover:bg-primary/10"
                    onMouseDown={() => {
                      setQuery("");
                      setOpen(false);
                      navigate({ to: "/anime/$slug", params: { slug: anime.slug } });
                    }}
                  >
                    <img
                      src={anime.poster}
                      alt={anime.titleAr}
                      loading="lazy"
                      className="size-10 rounded-md object-cover"
                    />
                    <span className="flex flex-col">
                      <span className="text-sm font-semibold">{anime.titleAr}</span>
                      <span className="text-xs text-muted-foreground">
                        {anime.titleEn}
                      </span>
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        {user ? (
          <span className="flex items-center gap-2 rounded-full bg-secondary/70 px-3 py-1.5 text-sm">
            <UserRound className="size-4 text-primary" />
            <span className="hidden sm:inline">{user}</span>
          </span>
        ) : (
          <Button
            className="neon-ring shrink-0 rounded-full font-bold"
            onClick={() => setLoginOpen(true)}
          >
            <LogIn className="size-4" />
            <span className="hidden sm:inline">تسجيل الدخول</span>
          </Button>
        )}
      </nav>

      <LoginModal
        open={loginOpen}
        onOpenChange={setLoginOpen}
        onGuest={() => setLoginOpen(false)}
        onLogin={(email) => {
          setUser(email.split("@")[0] ?? "زائر");
          setLoginOpen(false);
        }}
      />
    </header>
  );
}
