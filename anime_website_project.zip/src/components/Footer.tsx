export function Footer() {
  return (
    <footer className="mt-20 border-t border-border/60 bg-secondary/25">
      <div className="mx-auto flex max-w-7xl flex-col gap-3 px-4 py-8 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
        <p className="font-semibold text-foreground">
          أنمي <span className="neon-text">بلس</span> — منصة مشاهدة الأنمي بالعربية
        </p>
        <p>© {new Date().getFullYear()} جميع الحقوق محفوظة لأصحابها الأصليين.</p>
      </div>
    </footer>
  );
}
