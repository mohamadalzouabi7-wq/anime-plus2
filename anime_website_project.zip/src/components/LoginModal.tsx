import { useState } from "react";
import { Eye, Lock, Mail, Sparkles } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

type LoginModalProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onGuest: () => void;
  onLogin: (email: string) => void;
};

export function LoginModal({ open, onOpenChange, onGuest, onLogin }: LoginModalProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="surface-panel max-w-md rounded-2xl" dir="rtl">
        <DialogHeader className="text-right">
          <DialogTitle className="text-2xl font-bold">
            مرحباً بك في <span className="neon-text">أنمي بلس</span>
          </DialogTitle>
          <DialogDescription className="text-muted-foreground">
            تسجيل الدخول اختياري تماماً. يمكنك المتابعة كزائر ومشاهدة كل الحلقات دون
            أي قيود.
          </DialogDescription>
        </DialogHeader>

        <form
          className="space-y-4"
          onSubmit={(event) => {
            event.preventDefault();
            onLogin(email || "زائر مسجّل");
          }}
        >
          <div className="space-y-2">
            <Label htmlFor="email">البريد الإلكتروني</Label>
            <div className="relative">
              <Mail className="absolute right-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                id="email"
                type="email"
                required
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                placeholder="name@example.com"
                className="pr-10"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="password">كلمة المرور</Label>
            <div className="relative">
              <Lock className="absolute right-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                id="password"
                type="password"
                required
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                placeholder="••••••••"
                className="pr-10"
              />
            </div>
          </div>

          <Button type="submit" className="neon-ring w-full font-bold">
            <Sparkles className="size-4" />
            تسجيل الدخول
          </Button>
        </form>

        <Button
          type="button"
          variant="ghost"
          className="w-full text-muted-foreground hover:text-primary"
          onClick={onGuest}
        >
          <Eye className="size-4" />
          المتابعة كزائر بدون تسجيل
        </Button>
      </DialogContent>
    </Dialog>
  );
}
