import { useMemo, useState } from "react";
import { createFileRoute, notFound, Link } from "@tanstack/react-router";
import { ChevronLeft, ChevronRight, Clapperboard, Film, Play, Star } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { VideoPlayer } from "@/components/VideoPlayer";
import { getAnimeBySlug, getEpisodes, getMovies } from "@/data/anime";

export const Route = createFileRoute("/anime/$slug")({
  loader: ({ params }) => {
    const anime = getAnimeBySlug(params.slug);
    if (!anime) throw notFound();
    return anime;
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [
          { title: "الأنمي غير متوفر | أنمي بلس" },
          { name: "robots", content: "noindex" },
        ],
      };
    }
    const title = `مشاهدة ${loaderData.titleAr} (${loaderData.titleEn}) مترجم | أنمي بلس`;
    return {
      meta: [
        { title },
        { name: "description", content: loaderData.shortStory },
        { property: "og:title", content: title },
        { property: "og:description", content: loaderData.shortStory },
        { property: "og:type", content: "video.tv_show" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: AnimeDetails,
});

type Selection =
  | { kind: "episode"; index: number }
  | { kind: "movie"; index: number };

function AnimeDetails() {
  const anime = Route.useLoaderData();
  const episodes = useMemo(() => getEpisodes(anime), [anime]);
  const movies = useMemo(() => getMovies(anime), [anime]);
  const [selection, setSelection] = useState<Selection>({
    kind: "episode",
    index: 0,
  });

  const isEpisode = selection.kind === "episode";
  const current = isEpisode
    ? episodes[selection.index]!
    : movies[selection.index]!;
  const list = isEpisode ? episodes : movies;
  const currentIndex = selection.index;

  const selectAt = (index: number) =>
    setSelection({ kind: selection.kind, index });

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="mx-auto max-w-7xl px-4 py-8">
        <Link
          to="/"
          className="mb-6 inline-flex items-center gap-1 text-sm text-muted-foreground transition-colors hover:text-primary"
        >
          <ChevronRight className="size-4" />
          العودة إلى الصفحة الرئيسية
        </Link>

        <div className="grid gap-8 lg:grid-cols-[1fr_320px]">
          <div className="space-y-6">
            <VideoPlayer
              src={current.src}
              title={`${anime.titleAr} — ${current.title}`}
            />

            <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-border/70 bg-card p-4">
              <div>
                <p className="text-sm text-muted-foreground">
                  تشاهد الآن — {anime.titleAr}
                </p>
                <h2 className="text-lg font-bold">{current.title}</h2>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="secondary"
                  disabled={currentIndex === 0}
                  onClick={() => selectAt(Math.max(0, currentIndex - 1))}
                >
                  <ChevronRight className="size-4" />
                  {isEpisode ? "الحلقة السابقة" : "الفيلم السابق"}
                </Button>
                <Button
                  disabled={currentIndex === list.length - 1}
                  onClick={() =>
                    selectAt(Math.min(list.length - 1, currentIndex + 1))
                  }
                >
                  {isEpisode ? "الحلقة التالية" : "الفيلم التالي"}
                  <ChevronLeft className="size-4" />
                </Button>
              </div>
            </div>

            <section className="rounded-2xl border border-border/70 bg-card p-6">
              <h1 className="text-2xl font-extrabold sm:text-3xl">
                {anime.titleAr}{" "}
                <span className="text-base font-medium text-muted-foreground" dir="ltr">
                  {anime.titleEn}
                </span>
              </h1>
              <div className="mt-3 flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
                <span className="flex items-center gap-1 text-gold">
                  <Star className="size-4 fill-gold" />
                  {anime.rating.toFixed(1)}
                </span>
                <span>• {anime.year}</span>
                <span>• {anime.studio}</span>
                <span>• {anime.status}</span>
                <span>• {anime.episodeCount} حلقة</span>
                {anime.movieCount > 0 && <span>• {anime.movieCount} أفلام</span>}
              </div>
              <ul className="mt-4 flex flex-wrap gap-2">
                {anime.genres.map((genre) => (
                  <li
                    key={genre}
                    className="rounded-full border border-primary/25 bg-primary/10 px-3 py-1 text-xs text-primary"
                  >
                    {genre}
                  </li>
                ))}
              </ul>
              <p className="mt-5 leading-8 text-muted-foreground">{anime.story}</p>
            </section>
          </div>

          <aside className="space-y-3">
            <div className="overflow-hidden rounded-2xl border border-border/70">
              <img
                src={anime.poster}
                alt={`بوستر ${anime.titleAr}`}
                width={768}
                height={1024}
                className="w-full object-cover"
              />
            </div>

            {movies.length > 0 && (
              <div className="rounded-2xl border border-border/70 bg-card p-3">
                <h2 className="mb-3 flex items-center gap-2 px-1 text-sm font-bold">
                  <Film className="size-4 text-primary" />
                  الأفلام ({movies.length})
                </h2>
                <ul className="max-h-64 space-y-1 overflow-y-auto">
                  {movies.map((movie, movieIndex) => (
                    <li key={movie.number}>
                      <button
                        type="button"
                        onClick={() =>
                          setSelection({ kind: "movie", index: movieIndex })
                        }
                        className={`flex w-full items-center gap-3 rounded-xl p-2.5 text-right transition-colors ${
                          selection.kind === "movie" && movieIndex === currentIndex
                            ? "bg-primary/15 text-primary"
                            : "hover:bg-secondary/70"
                        }`}
                      >
                        <span className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-secondary text-xs font-bold">
                          {movie.number}
                        </span>
                        <span className="min-w-0 flex-1 truncate text-sm font-semibold">
                          {movie.title}
                        </span>
                        <Play className="size-3.5 shrink-0" />
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div className="rounded-2xl border border-border/70 bg-card p-3">
              <h2 className="mb-3 flex items-center gap-2 px-1 text-sm font-bold">
                <Clapperboard className="size-4 text-primary" />
                قائمة الحلقات ({episodes.length})
              </h2>
              <ul className="max-h-[28rem] space-y-1 overflow-y-auto">
                {episodes.map((item, itemIndex) => (
                  <li key={item.number}>
                    <button
                      type="button"
                      onClick={() =>
                        setSelection({ kind: "episode", index: itemIndex })
                      }
                      className={`flex w-full items-center gap-3 rounded-xl p-2.5 text-right transition-colors ${
                        selection.kind === "episode" && itemIndex === currentIndex
                          ? "bg-primary/15 text-primary"
                          : "hover:bg-secondary/70"
                      }`}
                    >
                      <span className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-secondary text-xs font-bold">
                        {item.number}
                      </span>
                      <span className="flex min-w-0 flex-1 flex-col">
                        <span className="truncate text-sm font-semibold">
                          {item.title}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {item.duration}
                        </span>
                      </span>
                      <Play className="size-3.5 shrink-0" />
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          </aside>
        </div>
      </main>

      <Footer />
    </div>
  );
}
