import { createFileRoute, Link } from "@tanstack/react-router";
import { Play, Star, Sparkles } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { AnimeCard } from "@/components/AnimeCard";
import { Button } from "@/components/ui/button";
import { animeList, featuredAnime } from "@/data/anime";
import heroBg from "@/assets/hero-bg.jpg";

const title = "أنمي بلس — مشاهدة أشهر الأنميات مترجمة بجودة عالية";
const description =
  "منصة أنمي بلس لمشاهدة أقوى مسلسلات الأنمي مترجمة للعربية: المحقق كونان، ون بيس، ناروتو، هجوم العمالقة، جوجوتسو كايسن، قاتل الشياطين، سولو ليفيلينغ وغيرها، بمشغّل سريع وبدون تسجيل إجباري.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main>
        <section className="relative overflow-hidden">
          <img
            src={heroBg}
            alt="مدينة طوكيو ليلاً بأضواء نيون — خلفية أنمي بلس"
            width={1920}
            height={1088}
            className="absolute inset-0 size-full object-cover opacity-45"
          />
          <div className="hero-fade absolute inset-0" />

          <div className="relative mx-auto grid max-w-7xl items-center gap-8 px-4 py-16 md:grid-cols-[1.4fr_1fr] md:py-24">
            <div className="space-y-5">
              <span className="surface-panel inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-semibold text-primary">
                <Sparkles className="size-3.5" />
                الأنمي المميّز هذا الأسبوع
              </span>
              <h1 className="text-4xl font-extrabold leading-tight sm:text-5xl md:text-6xl">
                {featuredAnime.titleAr}
                <span className="mt-2 block text-lg font-medium text-muted-foreground" dir="ltr">
                  {featuredAnime.titleEn}
                </span>
              </h1>
              <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
                <span className="flex items-center gap-1 text-gold">
                  <Star className="size-4 fill-gold" />
                  {featuredAnime.rating.toFixed(1)}
                </span>
                <span>• {featuredAnime.year}</span>
                <span>• {featuredAnime.genres.join(" · ")}</span>
              </div>
              <p className="max-w-2xl leading-8 text-muted-foreground">
                {featuredAnime.story}
              </p>
              <Button
                asChild
                size="lg"
                className="neon-ring h-14 rounded-full px-8 text-base font-extrabold"
              >
                <Link to="/anime/$slug" params={{ slug: featuredAnime.slug }}>
                  <Play className="size-5 fill-primary-foreground" />
                  شاهد الآن
                </Link>
              </Button>
            </div>

            <Link
              to="/anime/$slug"
              params={{ slug: featuredAnime.slug }}
              className="card-hover mx-auto hidden w-full max-w-xs overflow-hidden rounded-3xl border border-primary/30 md:block"
            >
              <img
                src={featuredAnime.poster}
                alt={`بوستر ${featuredAnime.titleAr}`}
                width={768}
                height={1024}
                className="w-full object-cover"
              />
            </Link>
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-4 py-14">
          <div className="mb-8 flex items-end justify-between gap-4">
            <div>
              <h2 className="text-2xl font-extrabold sm:text-3xl">
                أشهر <span className="neon-text">الأنميات</span> عالمياً
              </h2>
              <p className="mt-1 text-sm text-muted-foreground">
                ستة عشر عملاً صنعت تاريخ الأنمي، متاحة للمشاهدة الآن بدون تسجيل.
              </p>
            </div>
            <span className="hidden text-sm text-muted-foreground sm:block">
              {animeList.length} أعمال
            </span>
          </div>

          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6">
            {animeList.map((anime) => (
              <AnimeCard key={anime.slug} anime={anime} />
            ))}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
